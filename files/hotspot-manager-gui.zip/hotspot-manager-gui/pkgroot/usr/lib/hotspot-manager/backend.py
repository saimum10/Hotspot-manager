#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────
#   HOTSPOT MANAGER — Backend (runs entirely as root)
#   Saimum | Debian
#
#   Single active-network engine (stock hostapd/dnsmasq, one profile
#   active at a time — multiple saved profiles, switch with Activate).
# ─────────────────────────────────────────────────────────────
import os
import re
import json
import time
import signal
import pwd
import subprocess
import threading
import uuid

# ── PATHS ────────────────────────────────────────────────────
BASE_DIR            = "/etc/hotspot-manager"
NETWORKS_FILE       = f"{BASE_DIR}/networks.json"
ACTIVE_FILE         = f"{BASE_DIR}/active.json"
SETTINGS_FILE       = f"{BASE_DIR}/settings.json"
WHITELIST_FILE      = f"{BASE_DIR}/whitelist.conf"
BLACKLIST_FILE      = f"{BASE_DIR}/blacklist.conf"

HOSTAPD_CONF        = "/etc/hostapd/hostapd.conf"
DNSMASQ_CONF        = "/etc/dnsmasq.conf"
LEASES_FILE         = "/var/lib/misc/dnsmasq.leases"
HOTSPOT_IP          = "192.168.50.1"
DHCP_RANGE          = "192.168.50.2,192.168.50.20,255.255.255.0,24h"

STARTUP_UNIT        = "/etc/systemd/system/hotspot-manager-startup.service"
SLEEP_HOOK          = "/etc/systemd/system-sleep/hotspot-manager-resume.sh"

RUN_DIR             = "/run/hotspot-manager"
SLEEP_INHIBIT_PID   = f"{RUN_DIR}/sleep-inhibit.pid"
SLEEP_MONITOR_FLAG  = f"{RUN_DIR}/sleep-monitor.flag"
IDLE_STRIKES_FILE   = f"{RUN_DIR}/idle-strikes.json"

SUDOERS_FILE        = "/etc/sudoers.d/hotspot-manager"
MAIN_PY             = "/usr/lib/hotspot-manager/main.py"
CLI_PY              = "/usr/lib/hotspot-manager/cli.py"

# ── LOG BUFFER (in-process, shown in the Activity Log panel) ──
LOG_BUF  = []
LOG_LOCK = threading.Lock()


def add_log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with LOG_LOCK:
        LOG_BUF.append(line)
        if len(LOG_BUF) > 200:
            LOG_BUF.pop(0)
    print(line, flush=True)


def get_log(n=60):
    with LOG_LOCK:
        return list(LOG_BUF[-n:])


# ── LOW LEVEL HELPERS (already root — no sudo prefix needed) ──
def run_cmd(cmd, inp=None):
    try:
        r = subprocess.run(list(cmd), input=inp, capture_output=True,
                            text=True, timeout=60)
        if r.returncode != 0 and r.stderr and r.stderr.strip():
            add_log(f"⚠ {r.stderr.strip()[:150]}")
        return r
    except subprocess.TimeoutExpired:
        add_log(f"Timeout: {cmd[0]}")
        return None
    except Exception as e:
        add_log(f"Error: {e}")
        return None


def run_q(cmd):
    """Quiet run — used for polling/status checks, no log spam."""
    try:
        return subprocess.run(list(cmd), capture_output=True, text=True, timeout=10)
    except Exception:
        return None


def write_file(path, content):
    try:
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(path, "w") as f:
            f.write(content)
        return True
    except Exception as e:
        add_log(f"Write error {path}: {e}")
        return False


def read_file(path):
    try:
        with open(path) as f:
            return f.read()
    except Exception:
        return ""


def append_line(path, line):
    content = read_file(path)
    if content and not content.endswith("\n"):
        content += "\n"
    content += line + "\n"
    return write_file(path, content)


def get_real_user():
    u = os.environ.get("SUDO_USER")
    if u and u != "root":
        return u
    uid = os.environ.get("PKEXEC_UID")
    if uid:
        try:
            return pwd.getpwuid(int(uid)).pw_name
        except Exception:
            pass
    try:
        return os.getlogin()
    except Exception:
        return ""


# ── SETTINGS ─────────────────────────────────────────────────
def default_settings():
    return {
        "password_off": False,
        "whitelist_enabled": False,
        "block_sleep": False,
        "dark_mode": True,
        "show_password": False,
    }


def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        return default_settings()
    try:
        data = json.loads(read_file(SETTINGS_FILE) or "{}")
        merged = default_settings()
        merged.update(data)
        return merged
    except Exception:
        return default_settings()


def save_settings(s):
    write_file(SETTINGS_FILE, json.dumps(s, indent=2))


def set_dark_mode(is_dark):
    s = load_settings()
    s["dark_mode"] = bool(is_dark)
    save_settings(s)
    return {"ok": True}


def set_show_password(show):
    s = load_settings()
    s["show_password"] = bool(show)
    save_settings(s)
    return {"ok": True}


# ── NETWORK PROFILES (many saved, one active) ─────────────────
def get_networks():
    if not os.path.exists(NETWORKS_FILE):
        return []
    try:
        return json.loads(read_file(NETWORKS_FILE) or "[]")
    except Exception:
        return []


def save_networks(nets):
    write_file(NETWORKS_FILE, json.dumps(nets, indent=2))


def load_active_id():
    if not os.path.exists(ACTIVE_FILE):
        return None
    try:
        return json.loads(read_file(ACTIVE_FILE) or "{}").get("active_id")
    except Exception:
        return None


def save_active_id(nid):
    write_file(ACTIVE_FILE, json.dumps({"active_id": nid}))


def get_network(nid):
    for n in get_networks():
        if n["id"] == nid:
            return n
    return None


def get_active_network():
    nid = load_active_id()
    if not nid:
        return None
    return get_network(nid)


# ── ADAPTER DETECTION ────────────────────────────────────────
def list_wifi_ifaces():
    ifaces = []
    try:
        for name in os.listdir("/sys/class/net"):
            if (os.path.isdir(f"/sys/class/net/{name}/wireless")
                    or os.path.exists(f"/sys/class/net/{name}/phy80211")):
                ifaces.append(name)
    except Exception:
        pass
    return sorted(ifaces)


def get_default_route_iface():
    r = run_q(["ip", "route", "show", "default"])
    if r and r.stdout:
        m = re.search(r"dev (\S+)", r.stdout)
        if m:
            return m.group(1)
    return None


def list_other_ifaces(exclude=None):
    """Candidate internet-facing (uplink) interfaces — anything that isn't
    the loopback or a Wi-Fi adapter, with the current default route
    interface sorted first for convenience."""
    wifi = set(list_wifi_ifaces())
    ifaces = []
    try:
        for name in os.listdir("/sys/class/net"):
            if name in ("lo", exclude) or name in wifi:
                continue
            ifaces.append(name)
    except Exception:
        pass
    ifaces = sorted(set(ifaces))
    default_iface = get_default_route_iface()
    if default_iface and default_iface in ifaces:
        ifaces.remove(default_iface)
        ifaces.insert(0, default_iface)
    return ifaces


def get_bands_for_iface(iface):
    bands = []
    r = run_q(["iw", "dev", iface, "info"])
    phy = None
    if r and r.stdout:
        m = re.search(r"wiphy (\d+)", r.stdout)
        if m:
            phy = m.group(1)
    if phy is not None:
        r2 = run_q(["iw", "phy", f"phy{phy}", "info"])
        text = r2.stdout if r2 and r2.stdout else ""
        if re.search(r"Band 1", text):
            bands.append("2.4")
        if re.search(r"Band 2", text):
            bands.append("5")
    return bands or ["2.4"]


# ── HOSTAPD / DNSMASQ (stock config paths, stock services) ────
def write_hostapd_conf(net):
    hw_mode, channel = ("a", "36") if net["band"] == "5" else ("g", "6")
    hidden = "1" if net.get("hidden") else "0"
    settings = load_settings()
    acl_block = ""
    if settings.get("whitelist_enabled"):
        acl_block = f"\nmacaddr_acl=1\naccept_mac_file={WHITELIST_FILE}"
    elif os.path.exists(BLACKLIST_FILE) and os.path.getsize(BLACKLIST_FILE) > 0:
        acl_block = f"\nmacaddr_acl=0\ndeny_mac_file={BLACKLIST_FILE}"
    content = (
        f"interface={net['wifi_iface']}\ndriver=nl80211\n"
        f"ctrl_interface=/var/run/hostapd\nctrl_interface_group=0\n"
        f"utf8_ssid=1\nssid={net['ssid']}\nhw_mode={hw_mode}\nchannel={channel}\n"
        f"wpa=2\nwpa_passphrase={net['password']}\nwpa_key_mgmt=WPA-PSK\n"
        f"rsn_pairwise=CCMP\nignore_broadcast_ssid={hidden}{acl_block}\n"
    )
    write_file(HOSTAPD_CONF, content)


def write_dnsmasq_conf(net):
    content = f"interface={net['wifi_iface']}\nbind-interfaces\ndhcp-range={DHCP_RANGE}\n"
    write_file(DNSMASQ_CONF, content)


def _maybe_restart_hostapd():
    r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
    if r and r.returncode == 0:
        run_cmd(["systemctl", "restart", "hostapd"])


def is_hotspot_active():
    net = get_active_network()
    if not net:
        return False
    r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
    if not (r and r.returncode == 0):
        return False
    r2 = run_q(["ip", "addr", "show", net["wifi_iface"]])
    return bool(r2 and r2.stdout and HOTSPOT_IP in r2.stdout)


def is_permanent_enabled():
    r = run_q(["systemctl", "is-enabled", "--quiet", "hotspot-manager-startup.service"])
    return bool(r and r.returncode == 0)


def get_uptime():
    r = run_q(["systemctl", "show", "hostapd", "--property=ActiveEnterTimestamp"])
    if r and "=" in (r.stdout or ""):
        ts = r.stdout.strip().split("=", 1)[-1].strip()
        if ts:
            try:
                r2 = run_q(["date", "-d", ts, "+%s"])
                if r2 and r2.stdout.strip():
                    diff = int(time.time()) - int(r2.stdout.strip())
                    if diff < 0:
                        diff = 0
                    return f"{diff // 3600}h {(diff % 3600) // 60:02d}m"
            except Exception:
                pass
    return "--"


# ── STATUS ────────────────────────────────────────────────────
def get_status():
    net = get_active_network()
    settings = load_settings()
    show_pw = settings.get("show_password", False)
    s = {
        "has_network": net is not None,
        "network_id": net["id"] if net else None,
        "active": False, "ip": "N/A", "clients": 0, "uptime": "--",
        "name": net["name"] if net else None,
        "ssid": net["ssid"] if net else None,
        "password": ((net["password"] if show_pw else "•" * len(net["password"]))
                     if net else None),
        "show_password": show_pw,
        "band": net["band"] if net else None,
        "hidden": net["hidden"] if net else None,
        "wifi_iface": net["wifi_iface"] if net else None,
        "inet_iface": net["inet_iface"] if net else None,
        "permanent": is_permanent_enabled(),
        "sleep_block": is_sleep_block_active(),
        "password_off": settings.get("password_off", False),
        "whitelist_enabled": settings.get("whitelist_enabled", False),
        "block_sleep": settings.get("block_sleep", False),
        "dark_mode": settings.get("dark_mode", True),
    }
    if net:
        r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
        if r and r.returncode == 0:
            r2 = run_q(["ip", "addr", "show", net["wifi_iface"]])
            if r2 and r2.stdout and HOTSPOT_IP in r2.stdout:
                s["active"] = True
                s["ip"] = HOTSPOT_IP
                r3 = run_q(["iw", "dev", net["wifi_iface"], "station", "dump"])
                if r3 and r3.stdout:
                    s["clients"] = len([l for l in r3.stdout.split("\n")
                                         if l.strip().startswith("Station")])
                s["uptime"] = get_uptime()
    return s


# ── START / STOP ──────────────────────────────────────────────
def start_hotspot():
    net = get_active_network()
    if not net:
        add_log("✗ No network configured. Create one in the Network page first.")
        return {"error": "No active network"}
    add_log("Starting hotspot...")
    write_hostapd_conf(net)
    write_dnsmasq_conf(net)
    wifi, inet = net["wifi_iface"], net["inet_iface"]
    run_cmd(["nmcli", "device", "set", wifi, "managed", "no"])
    run_cmd(["ip", "link", "set", wifi, "up"])
    run_cmd(["ip", "addr", "add", f"{HOTSPOT_IP}/24", "dev", wifi])
    run_cmd(["sysctl", "-w", "net.ipv4.ip_forward=1"])
    if inet:
        run_cmd(["iptables", "-t", "nat", "-D", "POSTROUTING", "-o", inet, "-j", "MASQUERADE"])
        run_cmd(["iptables", "-t", "nat", "-A", "POSTROUTING", "-o", inet, "-j", "MASQUERADE"])
    run_q(["systemctl", "reset-failed", "hostapd.service"])
    run_cmd(["systemctl", "restart", "hostapd"])
    run_cmd(["systemctl", "restart", "dnsmasq"])
    time.sleep(1.5)

    r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
    r2 = run_q(["ip", "addr", "show", wifi])
    if r and r.returncode == 0 and r2 and r2.stdout and HOTSPOT_IP in r2.stdout:
        add_log(f"✓ Hotspot started! SSID: {net['ssid']} | {net['band']} GHz")
        settings = load_settings()
        if settings.get("block_sleep"):
            enable_sleep_block(wifi)
    else:
        hap_err = run_q(["journalctl", "-u", "hostapd", "-n", "8", "--no-pager"])
        detail = hap_err.stdout.strip() if hap_err and hap_err.stdout else "unknown error"
        add_log("✗ Failed to start. Details:")
        add_log(detail)
        return {"error": "hostapd failed to start (see Activity Log)"}
    return {"ok": True}


def stop_hotspot():
    net = get_active_network()
    add_log("Stopping hotspot...")
    run_cmd(["systemctl", "stop", "hostapd"])
    run_cmd(["systemctl", "stop", "dnsmasq"])
    run_cmd(["pkill", "-9", "-f", "/usr/sbin/hostapd"])
    run_cmd(["pkill", "-9", "-f", "/usr/sbin/dnsmasq"])
    if net:
        run_cmd(["ip", "addr", "del", f"{HOTSPOT_IP}/24", "dev", net["wifi_iface"]])
        run_cmd(["nmcli", "device", "set", net["wifi_iface"], "managed", "yes"])
    run_cmd(["iptables", "-t", "nat", "-F", "POSTROUTING"])
    disable_sleep_block()
    add_log("✓ Hotspot stopped and related processes killed")
    return {"ok": True}


# ── NETWORK CRUD ─────────────────────────────────────────────
def validate_network_input(d):
    if not d.get("name", "").strip():
        return "Please enter a network name"
    if not d.get("ssid", "").strip():
        return "SSID cannot be empty"
    if len(d.get("password", "")) < 8:
        return "Password must be at least 8 characters"
    if not d.get("wifi_iface"):
        return "Please select a Wi-Fi adapter"
    if not d.get("inet_iface"):
        return "Please select an internet adapter"
    if d.get("band") not in ("2.4", "5"):
        return "Please select a band"
    return None


def create_network(d):
    err = validate_network_input(d)
    if err:
        return {"error": err}
    nid = uuid.uuid4().hex[:8]
    net = {
        "id": nid, "name": d["name"].strip(), "ssid": d["ssid"].strip(),
        "password": d["password"], "band": d["band"], "hidden": bool(d.get("hidden")),
        "wifi_iface": d["wifi_iface"], "inet_iface": d["inet_iface"],
    }
    nets = get_networks()
    nets.append(net)
    save_networks(nets)
    if load_active_id() is None:
        save_active_id(nid)
    add_log(f"✓ Network '{net['name']}' created")
    return {"ok": True, "id": nid}


def update_network(nid, d):
    err = validate_network_input(d)
    if err:
        return {"error": err}
    nets = get_networks()
    found = False
    for n in nets:
        if n["id"] == nid:
            n.update({
                "name": d["name"].strip(), "ssid": d["ssid"].strip(),
                "password": d["password"], "band": d["band"],
                "hidden": bool(d.get("hidden")),
                "wifi_iface": d["wifi_iface"], "inet_iface": d["inet_iface"],
            })
            found = True
            break
    if not found:
        return {"error": "Network not found"}
    save_networks(nets)
    if load_active_id() == nid and is_hotspot_active():
        add_log("✓ Network updated — applying live...")
        start_hotspot()
    else:
        add_log("✓ Network updated. Start the hotspot to apply.")
    return {"ok": True}


def delete_network(nid):
    was_active = load_active_id() == nid
    if was_active:
        stop_hotspot()
    nets = [n for n in get_networks() if n["id"] != nid]
    save_networks(nets)
    if was_active:
        save_active_id(None)
    add_log("✓ Network deleted")
    return {"ok": True}


def activate_network(nid):
    if not get_network(nid):
        return {"error": "Network not found"}
    save_active_id(nid)
    add_log("✓ Active network changed. Press Start to bring it up.")
    return {"ok": True}


# ── DEVICES (active network only) ─────────────────────────────
_PREV_STATS = {}


def get_client_info(mac):
    mac_l = mac.lower()
    ip_, hostname, dev_type = "N/A", "unknown", ""
    leases = read_file(LEASES_FILE)
    for line in leases.split("\n"):
        parts = line.strip().split()
        if len(parts) >= 4 and parts[1].lower() == mac_l:
            ip_ = parts[2]
            hostname = parts[3] if parts[3] != "*" else "unknown"
            break
    hn = hostname.lower()
    if "android" in hn: dev_type = "Android"
    elif "iphone" in hn: dev_type = "iPhone"
    elif "ipad" in hn: dev_type = "iPad"
    elif any(x in hn for x in ("windows", "win")): dev_type = "Windows PC"
    elif any(x in hn for x in ("mac", "apple")): dev_type = "Mac"
    elif "linux" in hn: dev_type = "Linux"
    return ip_, hostname, dev_type


def get_devices():
    global _PREV_STATS
    net = get_active_network()
    if not net:
        return []
    r = run_q(["iw", "dev", net["wifi_iface"], "station", "dump"])
    if not r or not r.stdout or not r.stdout.strip():
        return []
    devices, cur = [], None
    for line in r.stdout.split("\n"):
        line = line.strip()
        if line.startswith("Station"):
            if cur:
                devices.append(cur)
            mac = line.split()[1]
            ip_, hostname, dtype = get_client_info(mac)
            cur = {"mac": mac, "ip": ip_, "hostname": hostname, "dev_type": dtype,
                   "signal": "", "tx_b": 0, "rx_b": 0}
        elif "signal:" in line and cur:
            cur["signal"] = line.split("signal:")[-1].strip().split()[0] + " dBm"
        elif "tx bytes:" in line and cur:
            try: cur["tx_b"] = int(line.split()[-1])
            except Exception: pass
        elif "rx bytes:" in line and cur:
            try: cur["rx_b"] = int(line.split()[-1])
            except Exception: pass
    if cur:
        devices.append(cur)

    now = time.time()
    new_prev, result = {}, []
    wl = read_file(WHITELIST_FILE).lower() if os.path.exists(WHITELIST_FILE) else ""
    bl = read_file(BLACKLIST_FILE).lower() if os.path.exists(BLACKLIST_FILE) else ""
    for d in devices:
        mac = d["mac"]
        ps = _PREV_STATS.get(mac, {})
        tx_speed = rx_speed = 0.0
        if ps:
            dt = now - ps.get("t", now)
            if dt > 0:
                tx_speed = max(0, (d["tx_b"] - ps.get("tx", d["tx_b"])) / dt / 1024)
                rx_speed = max(0, (d["rx_b"] - ps.get("rx", d["rx_b"])) / dt / 1024)
        new_prev[mac] = {"tx": d["tx_b"], "rx": d["rx_b"], "t": now}
        result.append({
            "mac": mac, "ip": d["ip"], "hostname": d["hostname"], "dev_type": d["dev_type"],
            "signal": d["signal"],
            "tx_speed": round(tx_speed, 1), "rx_speed": round(rx_speed, 1),
            "tx_mb": round(d["tx_b"] / 1048576, 2), "rx_mb": round(d["rx_b"] / 1048576, 2),
            "in_whitelist": mac.lower() in wl, "in_blacklist": mac.lower() in bl,
        })
    _PREV_STATS = new_prev
    return result


# ── WHITELIST / BLACKLIST ─────────────────────────────────────
def get_whitelist():
    return [l.strip() for l in read_file(WHITELIST_FILE).split("\n") if l.strip()]


def get_blacklist():
    return [l.strip() for l in read_file(BLACKLIST_FILE).split("\n") if l.strip()]


def enable_whitelist():
    net = get_active_network()
    if not os.path.exists(WHITELIST_FILE):
        write_file(WHITELIST_FILE, "")
    added = []
    if net:
        r = run_q(["iw", "dev", net["wifi_iface"], "station", "dump"])
        if r and r.stdout:
            existing = read_file(WHITELIST_FILE).lower()
            for line in r.stdout.split("\n"):
                if line.strip().startswith("Station"):
                    mac = line.strip().split()[1]
                    if mac.lower() not in existing:
                        append_line(WHITELIST_FILE, mac)
                        existing += mac.lower() + "\n"
                        added.append(mac)
    s = load_settings(); s["whitelist_enabled"] = True; save_settings(s)
    if net:
        write_hostapd_conf(net)
    _maybe_restart_hostapd()
    add_log(f"✓ Whitelist enabled. {len(added)} device(s) auto-added.")
    return {"ok": True}


def disable_whitelist():
    s = load_settings(); s["whitelist_enabled"] = False; save_settings(s)
    net = get_active_network()
    if net:
        write_hostapd_conf(net)
    _maybe_restart_hostapd()
    add_log("✓ Whitelist disabled — network is now OPEN")
    return {"ok": True}


def add_to_whitelist(mac):
    if not os.path.exists(WHITELIST_FILE):
        write_file(WHITELIST_FILE, "")
    existing = read_file(WHITELIST_FILE).lower()
    if mac.lower() not in existing:
        append_line(WHITELIST_FILE, mac)
        net = get_active_network()
        if net:
            write_hostapd_conf(net)
        _maybe_restart_hostapd()
        add_log(f"✓ {mac} added to whitelist")
    else:
        add_log(f"~ {mac} is already in the whitelist")
    return {"ok": True}


def remove_from_whitelist(mac):
    run_cmd(["sed", "-i", f"/^{re.escape(mac)}$/Id", WHITELIST_FILE])
    net = get_active_network()
    if net:
        write_hostapd_conf(net)
    _maybe_restart_hostapd()
    add_log(f"✓ {mac} removed from whitelist")
    return {"ok": True}


def kick_ban(mac, iface=None):
    net = get_active_network()
    wifi_iface = iface or (net["wifi_iface"] if net else None)
    add_log(f"Kicking {mac}...")
    if wifi_iface:
        r = run_cmd(["hostapd_cli", "-p", "/var/run/hostapd", "-i", wifi_iface,
                      "deauthenticate", mac])
        if not r or r.returncode != 0:
            run_cmd(["iw", "dev", wifi_iface, "station", "del", mac])
    if not os.path.exists(BLACKLIST_FILE):
        write_file(BLACKLIST_FILE, "")
    existing = read_file(BLACKLIST_FILE).lower()
    if mac.lower() not in existing:
        append_line(BLACKLIST_FILE, mac)
    if net:
        write_hostapd_conf(net)
    _maybe_restart_hostapd()
    add_log(f"✓ {mac} kicked + banned")
    return {"ok": True}


def unban(mac):
    run_cmd(["sed", "-i", f"/^{re.escape(mac)}$/Id", BLACKLIST_FILE])
    net = get_active_network()
    if net:
        write_hostapd_conf(net)
    _maybe_restart_hostapd()
    add_log(f"✓ {mac} unbanned")
    return {"ok": True}


# ── SLEEP BLOCK (systemd-inhibit + idle auto-disable monitor) ─
def enable_sleep_block(wifi_iface=None):
    r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
    if not r or r.returncode != 0:
        add_log("✗ Hotspot is not active — cannot enable sleep block")
        return
    if not wifi_iface:
        net = get_active_network()
        wifi_iface = net["wifi_iface"] if net else None
    os.makedirs(RUN_DIR, exist_ok=True)
    if os.path.exists(SLEEP_INHIBIT_PID):
        try:
            pid = int(read_file(SLEEP_INHIBIT_PID).strip())
            os.kill(pid, 0)
            return
        except Exception:
            try: os.remove(SLEEP_INHIBIT_PID)
            except Exception: pass
    r2 = run_q(["which", "systemd-inhibit"])
    if not r2 or r2.returncode != 0:
        add_log("✗ systemd-inhibit not found")
        return
    proc = subprocess.Popen(
        ["systemd-inhibit", "--what=sleep:idle", "--who=Hotspot Manager",
         "--why=Hotspot is active", "sleep", "infinity"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    write_file(SLEEP_INHIBIT_PID, str(proc.pid))
    add_log(f"✓ Sleep block enabled (PID {proc.pid})")
    if wifi_iface:
        _start_sleep_monitor(wifi_iface)


def disable_sleep_block():
    try:
        if os.path.exists(SLEEP_MONITOR_FLAG):
            os.remove(SLEEP_MONITOR_FLAG)
    except Exception:
        pass
    if os.path.exists(SLEEP_INHIBIT_PID):
        try:
            pid = int(read_file(SLEEP_INHIBIT_PID).strip())
            try:
                os.kill(pid, signal.SIGTERM)
                time.sleep(0.2)
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        except Exception:
            pass
        try: os.remove(SLEEP_INHIBIT_PID)
        except Exception: pass
    add_log("✓ Sleep block disabled")


def is_sleep_block_active():
    if not os.path.exists(SLEEP_INHIBIT_PID):
        return False
    try:
        pid = int(read_file(SLEEP_INHIBIT_PID).strip())
        os.kill(pid, 0)
        return True
    except Exception:
        try: os.remove(SLEEP_INHIBIT_PID)
        except Exception: pass
        return False


def _start_sleep_monitor(wifi_iface):
    """Background thread (lives only while the app process is running):
    auto-disables the sleep block after ~3 idle minutes (0 clients)."""
    flag_token = str(time.time())
    write_file(SLEEP_MONITOR_FLAG, flag_token)

    def _monitor():
        idle_count = 0
        while True:
            time.sleep(60)
            if read_file(SLEEP_MONITOR_FLAG).strip() != flag_token:
                return  # a newer monitor (or a disable) superseded this one
            if not os.path.exists(SLEEP_INHIBIT_PID):
                return
            try:
                pid = int(read_file(SLEEP_INHIBIT_PID).strip())
                os.kill(pid, 0)
            except Exception:
                return
            r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
            if not r or r.returncode != 0:
                disable_sleep_block()
                return
            r2 = run_q(["iw", "dev", wifi_iface, "station", "dump"])
            clients = len([l for l in (r2.stdout if r2 and r2.stdout else "").split("\n")
                           if l.strip().startswith("Station")])
            if clients == 0:
                idle_count += 1
                if idle_count >= 3:
                    disable_sleep_block()
                    return
            else:
                idle_count = 0

    threading.Thread(target=_monitor, daemon=True).start()


def toggle_sleep_block(want_on):
    s = load_settings()
    net = get_active_network()
    if not want_on:
        disable_sleep_block()
        s["block_sleep"] = False
        save_settings(s)
        return {"status": "off"}
    if net:
        enable_sleep_block(net["wifi_iface"])
    s["block_sleep"] = True
    save_settings(s)
    return {"status": "on"}


# ── AUTO-START ON BOOT (formerly "Permanent") ─────────────────
def make_permanent():
    add_log("Enabling auto-start on boot...")
    if not get_active_network():
        add_log("⚠ No active network — create and activate one first")
        return {"error": "No active network"}
    svc = (
        "[Unit]\nDescription=Hotspot Manager - Startup\n"
        "After=network.target NetworkManager.service hostapd.service dnsmasq.service\n"
        "Wants=network.target\n\n[Service]\nType=oneshot\n"
        "ExecStartPre=/bin/sleep 5\n"
        f"ExecStart=/usr/bin/python3 {CLI_PY} start\n"
        "RemainAfterExit=yes\nTimeoutStartSec=30\n\n"
        "[Install]\nWantedBy=multi-user.target\n"
    )
    write_file(STARTUP_UNIT, svc)
    run_cmd(["mkdir", "-p", "/etc/systemd/system-sleep"])
    resume_hook = (
        '#!/bin/bash\ncase "$1" in\n'
        f'    post) sleep 5 && /usr/bin/python3 {CLI_PY} start & ;;\nesac\n'
    )
    write_file(SLEEP_HOOK, resume_hook)
    run_cmd(["chmod", "+x", SLEEP_HOOK])
    r = run_q(["grep", "-q", "net.ipv4.ip_forward=1", "/etc/sysctl.conf"])
    if not r or r.returncode != 0:
        run_cmd(["bash", "-c", "echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf"])
    run_cmd(["systemctl", "daemon-reload"])
    run_cmd(["systemctl", "enable", "hotspot-manager-startup.service"])
    run_cmd(["systemctl", "enable", "hostapd"])
    run_cmd(["systemctl", "enable", "dnsmasq"])
    r2 = run_q(["which", "netfilter-persistent"])
    if not r2 or r2.returncode != 0:
        run_cmd(["apt-get", "install", "-y", "iptables-persistent"])
    run_cmd(["netfilter-persistent", "save"])
    add_log("✓ Hotspot will now auto-start on every boot/resume")
    return {"ok": True}


def reset_permanent():
    add_log("Disabling auto-start on boot...")
    run_cmd(["systemctl", "disable", "hotspot-manager-startup.service"])
    run_cmd(["systemctl", "disable", "hostapd"])
    run_cmd(["systemctl", "disable", "dnsmasq"])
    run_cmd(["rm", "-f", STARTUP_UNIT, SLEEP_HOOK])
    run_cmd(["sed", "-i", "/net.ipv4.ip_forward=1/d", "/etc/sysctl.conf"])
    r = run_q(["which", "netfilter-persistent"])
    if r and r.returncode == 0:
        run_cmd(["netfilter-persistent", "flush"])
    run_cmd(["systemctl", "daemon-reload"])
    add_log("✓ Auto-start on boot disabled")
    return {"ok": True}


# ── SCHEDULE (root crontab — works even if the app is closed) ─
def get_schedule():
    r = run_q(["crontab", "-l"])
    s = {"on_h": None, "on_m": None, "off_h": None, "off_m": None, "idle_mins": None}
    if not r or not r.stdout:
        return s
    for line in r.stdout.split("\n"):
        if "# hotspot-on" in line and not line.startswith("#"):
            p = line.strip().split()
            if len(p) >= 2:
                try: s["on_m"], s["on_h"] = int(p[0]), int(p[1])
                except Exception: pass
        elif "# hotspot-off" in line and not line.startswith("#"):
            p = line.strip().split()
            if len(p) >= 2:
                try: s["off_m"], s["off_h"] = int(p[0]), int(p[1])
                except Exception: pass
        elif "# hotspot-idle" in line and not line.startswith("#"):
            m = re.search(r"\*/(\d+)", line)
            if m:
                s["idle_mins"] = int(m.group(1))
    return s


def _cron_update(tag, new_line=None):
    r = run_q(["crontab", "-l"])
    existing = r.stdout if r and r.stdout else ""
    lines = [l for l in existing.split("\n") if l.strip() and f"# {tag}" not in l]
    if new_line:
        lines.append(new_line)
    new_cron = "\n".join(lines) + "\n"
    subprocess.run(["crontab", "-"], input=new_cron, text=True, capture_output=True)


def set_schedule_on(h, m):
    cmd = f"/usr/bin/python3 {CLI_PY} start"
    _cron_update("hotspot-on", f"{m} {h} * * * {cmd} # hotspot-on")
    add_log(f"✓ Auto ON set to {h:02d}:{m:02d}")
    return {"ok": True}


def set_schedule_off(h, m):
    cmd = f"/usr/bin/python3 {CLI_PY} stop"
    _cron_update("hotspot-off", f"{m} {h} * * * {cmd} # hotspot-off")
    add_log(f"✓ Auto OFF set to {h:02d}:{m:02d}")
    return {"ok": True}


def set_idle_timeout(mins):
    cmd = f"/usr/bin/python3 {CLI_PY} idle-check"
    _cron_update("hotspot-idle", f"*/{mins} * * * * {cmd} # hotspot-idle ({mins} min)")
    add_log(f"✓ Idle timeout set to {mins} min")
    return {"ok": True}


def clear_schedule(what):
    tags = {"on": ["hotspot-on"], "off": ["hotspot-off"], "idle": ["hotspot-idle"],
            "all": ["hotspot-on", "hotspot-off", "hotspot-idle"]}
    for tag in tags.get(what, []):
        _cron_update(tag)
    add_log(f"✓ Schedule cleared: {what}")
    return {"ok": True}


def idle_check():
    """Invoked from cron. Stops the hotspot only after clients have been
    absent for two consecutive checks in a row — a single zero reading can
    just be a phone's wifi radio briefly sleeping, not a real idle hotspot,
    so one blip alone must not shut it off."""
    net = get_active_network()
    if not net:
        write_file(IDLE_STRIKES_FILE, "")
        return
    r = run_q(["systemctl", "is-active", "--quiet", "hostapd"])
    if not r or r.returncode != 0:
        write_file(IDLE_STRIKES_FILE, "")
        return
    r2 = run_q(["iw", "dev", net["wifi_iface"], "station", "dump"])
    clients = len([l for l in (r2.stdout if r2 and r2.stdout else "").split("\n")
                   if l.strip().startswith("Station")])

    try:
        state = json.loads(read_file(IDLE_STRIKES_FILE) or "{}")
    except Exception:
        state = {}
    strikes = state.get("strikes", 0) if state.get("net_id") == net.get("id") else 0

    if clients > 0:
        write_file(IDLE_STRIKES_FILE, "")
        return

    strikes += 1
    if strikes >= 2:
        add_log("Idle timeout: no devices connected — stopping hotspot")
        write_file(IDLE_STRIKES_FILE, "")
        stop_hotspot()
    else:
        add_log(f"Idle timeout: no devices connected (check {strikes}/2 — will stop next time if still empty)")
        write_file(IDLE_STRIKES_FILE, json.dumps({"net_id": net.get("id"), "strikes": strikes}))


# ── QR CODE (active network only) ─────────────────────────────
def get_qr():
    net = get_active_network()
    if not net:
        return {"error": "No network configured"}
    r = run_q(["which", "qrencode"])
    if not r or r.returncode != 0:
        return {"error": "qrencode is not installed. Run Setup > Install & Configure first."}
    hidden_flag = ";H:true" if net["hidden"] else ""
    wifi_str = f"WIFI:S:{net['ssid']};T:WPA;P:{net['password']}{hidden_flag};;"
    r2 = subprocess.run(["qrencode", "-t", "SVG", "-o", "-", wifi_str],
                         capture_output=True, text=True)
    if r2.returncode == 0:
        return {"svg": r2.stdout, "ssid": net["ssid"], "band": net["band"],
                "hidden": net["hidden"]}
    return {"error": "Failed to generate QR code"}


# ── SETUP: INSTALL / DELETE ALL / APP PASSWORD ────────────────
def install_configure():
    add_log("[1/5] Updating package list...")
    run_cmd(["apt-get", "update", "-qq"])
    add_log("[2/5] Installing hostapd, dnsmasq, iptables, qrencode...")
    run_cmd(["apt-get", "install", "-y", "hostapd", "dnsmasq", "iptables", "qrencode"])
    add_log("[3/5] Unmasking hostapd...")
    run_cmd(["systemctl", "unmask", "hostapd"])
    add_log("[4/5] Pointing hostapd at its config file...")
    run_cmd(["sed", "-i", r's|#DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|',
             "/etc/default/hostapd"])
    add_log("[5/5] Preparing base configuration...")
    os.makedirs(BASE_DIR, exist_ok=True)
    for f in (WHITELIST_FILE, BLACKLIST_FILE):
        if not os.path.exists(f):
            write_file(f, "")
    if not os.path.exists(NETWORKS_FILE):
        save_networks([])
    if not os.path.exists(SETTINGS_FILE):
        save_settings(default_settings())
    add_log("✓ Setup complete. Create a network in the Network page.")
    return {"ok": True}


def delete_all_setup():
    add_log("Deleting all setup — please wait...")
    stop_hotspot()
    reset_permanent()
    for tag in ("hotspot-on", "hotspot-off", "hotspot-idle"):
        _cron_update(tag)
    for f in (NETWORKS_FILE, ACTIVE_FILE, WHITELIST_FILE, BLACKLIST_FILE,
              HOSTAPD_CONF, DNSMASQ_CONF, SUDOERS_FILE):
        run_cmd(["rm", "-f", f])
    run_cmd(["sed", "-i", r'''s|DAEMON_CONF=.*|#DAEMON_CONF=""|''', "/etc/default/hostapd"])
    add_log("[*] Removing packages (hostapd, dnsmasq, qrencode, iptables)...")
    run_cmd(["apt-get", "remove", "-y", "--purge", "hostapd", "dnsmasq", "qrencode", "iptables"])
    run_cmd(["apt-get", "autoremove", "-y"])
    save_settings(default_settings())
    save_networks([])
    add_log("✓ All setup deleted. Run Install & Configure again to start over.")
    return {"ok": True}


def _sudoers_content(real_user):
    return (
        f'Defaults:{real_user} env_keep += "DISPLAY XAUTHORITY QT_QPA_PLATFORM '
        f'WAYLAND_DISPLAY XDG_RUNTIME_DIR HOME"\n'
        f'{real_user} ALL=(root) NOPASSWD: /usr/bin/python3 {MAIN_PY}\n'
    )


def _write_password_off_sudoers(real_user):
    if not run_q(["which", "sudo"]) or run_q(["which", "sudo"]).returncode != 0:
        add_log("sudo package not found — installing it first...")
        run_cmd(["apt-get", "update", "-qq"])
        run_cmd(["apt-get", "install", "-y", "sudo"])
    if not run_q(["which", "visudo"]) or run_q(["which", "visudo"]).returncode != 0:
        add_log("✗ visudo not available even after installing sudo — aborting")
        return False

    content = _sudoers_content(real_user)
    tmp_path = f"{SUDOERS_FILE}.tmp"
    write_file(tmp_path, content)
    run_cmd(["chmod", "440", tmp_path])
    check = run_q(["visudo", "-cf", tmp_path])
    if not check or check.returncode != 0:
        err = check.stderr.strip() if check and check.stderr else "unknown error"
        add_log(f"✗ Invalid sudoers rule, not applied: {err}")
        run_cmd(["rm", "-f", tmp_path])
        return False
    run_cmd(["mv", tmp_path, SUDOERS_FILE])
    run_cmd(["chmod", "440", SUDOERS_FILE])
    return True


def ensure_password_off_sudoers():
    s = load_settings()
    if not s.get("password_off"):
        return
    real_user = get_real_user()
    if not real_user:
        return
    expected = _sudoers_content(real_user)
    current = read_file(SUDOERS_FILE) if os.path.exists(SUDOERS_FILE) else ""
    if current != expected:
        add_log("Refreshing no-password sudoers rule...")
        _write_password_off_sudoers(real_user)


def toggle_app_password():
    s = load_settings()
    s["password_off"] = not s.get("password_off", False)
    if s["password_off"]:
        real_user = get_real_user()
        if not real_user:
            add_log("✗ Could not detect the username")
            return {"error": "Could not detect the username"}
        if not _write_password_off_sudoers(real_user):
            add_log("✗ Could not enable no-password mode — left unchanged")
            return {"error": "Failed to enable no-password mode (see Activity Log)"}
        add_log("✓ App Password OFF — will now launch without a password")
    else:
        run_cmd(["rm", "-f", SUDOERS_FILE])
        add_log("✓ App Password ON — will now require a password to launch")
    save_settings(s)
    return {"status": "off" if s["password_off"] else "on"}
