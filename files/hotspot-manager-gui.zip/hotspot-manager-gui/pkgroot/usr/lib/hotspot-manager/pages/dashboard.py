from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QMessageBox,
)
from PyQt5.QtCore import Qt, QThreadPool

import backend
from worker import Worker
from widgets import Card, StatCard, SectionTitle, Hint, Badge, make_button, ToggleSwitch


class DashboardPage(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.mw = main_window
        self.pool = QThreadPool.globalInstance()
        self._busy = False
        self._pending_action = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        self.v = QVBoxLayout(content)
        self.v.setContentsMargins(24, 20, 24, 20)
        self.v.setSpacing(16)

        self.v.addWidget(SectionTitle("Dashboard"))

        # empty state (no network at all yet)
        self.empty_card = Card()
        self.empty_card.addWidget(SectionTitle("No Network Yet"))
        self.empty_card.addWidget(Hint(
            "Create a Wi-Fi network in the Network page, then come back here to turn it on."))
        self.v.addWidget(self.empty_card)

        # stat row
        self.stat_row_wrap = QWidget()
        stat_row = QHBoxLayout(self.stat_row_wrap)
        stat_row.setContentsMargins(0, 0, 0, 0)
        stat_row.setSpacing(12)
        self.stat_status = StatCard("STATUS", "OFF")
        self.stat_clients = StatCard("CLIENTS", "0")
        self.stat_ip = StatCard("IP ADDRESS", "--")
        self.stat_uptime = StatCard("UPTIME", "--")
        for s in (self.stat_status, self.stat_clients, self.stat_ip, self.stat_uptime):
            stat_row.addWidget(s)
        self.v.addWidget(self.stat_row_wrap)

        # active network info card
        self.info_card = Card()
        info_top = QHBoxLayout()
        self.net_title = QLabel("—")
        self.net_title.setStyleSheet("font-size: 15px; font-weight: 700;")
        info_top.addWidget(self.net_title)
        info_top.addStretch()
        self.band_badge = Badge("--", "info")
        self.vis_badge = Badge("--", "off")
        info_top.addWidget(self.band_badge)
        info_top.addWidget(self.vis_badge)
        self.info_card.addLayout(info_top)

        pw_row = QHBoxLayout()
        pw_row.addWidget(QLabel("Password:"))
        self.pw_label = QLabel("--")
        pw_row.addWidget(self.pw_label)
        self.eye_btn = make_button("👁", "flat")
        self.eye_btn.setFixedWidth(34)
        self.eye_btn.clicked.connect(self.on_toggle_pw_visible)
        pw_row.addWidget(self.eye_btn)
        pw_row.addStretch()
        view_qr_btn = make_button("🔳 View QR")
        view_qr_btn.clicked.connect(lambda: self.mw.switch_page("qrcode"))
        pw_row.addWidget(view_qr_btn)
        self.info_card.addLayout(pw_row)
        self.v.addWidget(self.info_card)

        # main hotspot toggle
        power_card = Card()
        power_row = QHBoxLayout()
        power_label_col = QVBoxLayout()
        power_title = QLabel("Hotspot")
        power_title.setStyleSheet("font-size: 15px; font-weight: 700;")
        power_label_col.addWidget(power_title)
        self.power_hint = Hint("Turn on to start broadcasting")
        power_label_col.addWidget(self.power_hint)
        power_row.addLayout(power_label_col)
        power_row.addStretch()
        self.power_toggle = ToggleSwitch()
        self.power_toggle.setFixedSize(60, 32)
        self.power_toggle.stateChanged.connect(self.on_toggle_power)
        power_row.addWidget(self.power_toggle)
        power_card.addLayout(power_row)
        self.v.addWidget(power_card)

        # sleep block + auto-boot toggles
        toggles_card = Card()
        sleep_row = QHBoxLayout()
        sleep_col = QVBoxLayout()
        sleep_col.addWidget(QLabel("Prevent Sleep While Active"))
        sleep_col.addWidget(Hint("Laptop won't sleep/suspend while the hotspot is on."))
        sleep_row.addLayout(sleep_col)
        sleep_row.addStretch()
        self.sleep_toggle = ToggleSwitch()
        self.sleep_toggle.stateChanged.connect(self.on_toggle_sleep)
        sleep_row.addWidget(self.sleep_toggle)
        toggles_card.addLayout(sleep_row)

        boot_row = QHBoxLayout()
        boot_col = QVBoxLayout()
        boot_col.addWidget(QLabel("Auto-start on Boot"))
        boot_col.addWidget(Hint("Automatically turns the hotspot back on after every restart."))
        boot_row.addLayout(boot_col)
        boot_row.addStretch()
        self.boot_toggle = ToggleSwitch()
        self.boot_toggle.stateChanged.connect(self.on_toggle_boot)
        boot_row.addWidget(self.boot_toggle)
        toggles_card.addLayout(boot_row)
        self.v.addWidget(toggles_card)

        self.v.addStretch()
        self.refresh()

    # ── data refresh ──────────────────────────────────────────
    def refresh(self):
        if self._busy:
            return
        self._busy = True
        w = Worker(backend.get_status)
        w.signals.finished.connect(self._apply_status)
        w.signals.error.connect(lambda e: setattr(self, "_busy", False))
        self.pool.start(w)

    def _apply_status(self, status):
        self._busy = False
        has_net = status["has_network"]
        self.empty_card.setVisible(not has_net)
        self.stat_row_wrap.setVisible(has_net)
        self.info_card.setVisible(has_net)

        if not has_net:
            return

        active = status["active"]
        self.stat_status.set_value("ON" if active else "OFF")
        self.stat_clients.set_value(status["clients"])
        self.stat_ip.set_value(status["ip"] if active else "--")
        self.stat_uptime.set_value(status["uptime"] if active else "--")

        self.net_title.setText(f"📶  {status['name']}  ({status['ssid']})")
        self.band_badge.set_variant("info", f"{status['band']} GHz")
        self.vis_badge.set_variant("warn" if status["hidden"] else "off",
                                    "Hidden" if status["hidden"] else "Visible")
        self.pw_label.setText(status["password"])
        self.eye_btn.setText("🙈" if status["show_password"] else "👁")

        self.power_hint.setText("Broadcasting now" if active else "Turn on to start broadcasting")
        if not self._pending_action:
            self.power_toggle.blockSignals(True)
            self.power_toggle.setChecked(active)
            self.power_toggle.blockSignals(False)

            self.sleep_toggle.blockSignals(True)
            self.sleep_toggle.setChecked(status["sleep_block"])
            self.sleep_toggle.blockSignals(False)

            self.boot_toggle.blockSignals(True)
            self.boot_toggle.setChecked(status["permanent"])
            self.boot_toggle.blockSignals(False)

    def on_toggle_pw_visible(self):
        w = Worker(backend.load_settings)

        def apply(settings):
            new_val = not settings.get("show_password", False)
            backend.set_show_password(new_val)
            self.refresh()

        w.signals.finished.connect(apply)
        self.pool.start(w)

    # ── actions ───────────────────────────────────────────────
    def on_toggle_power(self, state):
        want_on = self.power_toggle.isChecked()
        self._pending_action = True
        self.power_toggle.setEnabled(False)
        fn = backend.start_hotspot if want_on else backend.stop_hotspot
        w = Worker(fn)
        w.signals.finished.connect(lambda r: self._after_power(r, want_on))
        self.pool.start(w)

    def _after_power(self, result, wanted_on):
        self.power_toggle.setEnabled(True)
        self._pending_action = False
        if result and result.get("error"):
            self.mw.toast.show_message(result["error"], "error")
        else:
            self.mw.toast.show_message(
                "✓ Hotspot started" if wanted_on else "✓ Hotspot stopped",
                "success" if wanted_on else "info")
        self.refresh()

    def on_toggle_sleep(self, state):
        want_on = self.sleep_toggle.isChecked()
        self._pending_action = True
        w = Worker(backend.toggle_sleep_block, want_on)
        w.signals.finished.connect(lambda r: self._after_side_toggle(r))
        self.pool.start(w)

    def on_toggle_boot(self, state):
        want_on = self.boot_toggle.isChecked()
        if not want_on:
            reply = QMessageBox.question(
                self, "Auto-start on Boot",
                "Turn off auto-start on boot?",
                QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                self.refresh()
                return
        self._pending_action = True
        fn = backend.make_permanent if want_on else backend.reset_permanent
        w = Worker(fn)
        w.signals.finished.connect(lambda r: self._after_boot_toggle(r))
        self.pool.start(w)

    def _after_side_toggle(self, result):
        self._pending_action = False
        if result and isinstance(result, dict) and result.get("error"):
            self.mw.toast.show_message(result["error"], "error")
        self.refresh()

    def _after_boot_toggle(self, result):
        self._pending_action = False
        if result and result.get("error"):
            self.mw.toast.show_message(result["error"], "error")
        else:
            self.mw.toast.show_message("✓ Setting updated", "success")
        self.refresh()
