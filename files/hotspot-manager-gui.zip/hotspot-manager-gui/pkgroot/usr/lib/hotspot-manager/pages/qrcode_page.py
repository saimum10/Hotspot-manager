from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
)
from PyQt5.QtCore import Qt, QThreadPool, QByteArray

try:
    from PyQt5.QtSvg import QSvgWidget
    HAS_QTSVG = True
except Exception:
    QSvgWidget = None
    HAS_QTSVG = False

import backend
from worker import Worker
from widgets import Card, SectionTitle, Hint, make_button


class QrCodePage(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.mw = main_window
        self.pool = QThreadPool.globalInstance()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        self.v = QVBoxLayout(content)
        self.v.setContentsMargins(24, 20, 24, 20)
        self.v.setSpacing(16)

        self.v.addWidget(SectionTitle("QR Code"))
        self.v.addWidget(Hint("Scan the QR code to connect to the active network's Wi-Fi instantly."))

        self.qr_card = Card()
        self.qr_card.setMinimumHeight(320)
        if HAS_QTSVG:
            self.qr_svg = QSvgWidget()
            self.qr_svg.setFixedSize(260, 260)
        else:
            self.qr_svg = QLabel("QtSvg module not found —\nrun 'sudo apt install python3-pyqt5.qtsvg'")
            self.qr_svg.setFixedSize(260, 260)
            self.qr_svg.setAlignment(Qt.AlignCenter)
            self.qr_svg.setWordWrap(True)
        qr_wrap = QHBoxLayout()
        qr_wrap.addStretch()
        qr_wrap.addWidget(self.qr_svg)
        qr_wrap.addStretch()
        self.qr_card.addLayout(qr_wrap)
        self.info_lbl = QLabel("Loading...")
        self.info_lbl.setAlignment(Qt.AlignCenter)
        self.qr_card.addWidget(self.info_lbl)
        refresh_btn = make_button("Refresh", "primary")
        refresh_btn.clicked.connect(self.refresh)
        self.qr_card.addWidget(refresh_btn)
        self.v.addWidget(self.qr_card)
        self.v.addStretch()

        self.refresh()

    def refresh(self):
        w = Worker(backend.get_qr)
        w.signals.finished.connect(self._apply)
        self.pool.start(w)

    def _apply(self, result):
        if result.get("error"):
            self.info_lbl.setText(result["error"])
            return
        if HAS_QTSVG:
            self.qr_svg.load(QByteArray(result["svg"].encode("utf-8")))
        vis = "Hidden" if result["hidden"] else "Visible"
        self.info_lbl.setText(f"SSID: {result['ssid']}   •   Band: {result['band']} GHz   •   {vis}")
