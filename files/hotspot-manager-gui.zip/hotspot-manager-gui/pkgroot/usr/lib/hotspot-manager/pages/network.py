from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QDialog,
    QLineEdit, QComboBox, QRadioButton, QButtonGroup, QMessageBox,
    QFormLayout,
)
from PyQt5.QtCore import Qt, QThreadPool

import backend
from worker import Worker
from widgets import Card, SectionTitle, Hint, Badge, make_button


class NetworkDialog(QDialog):
    def __init__(self, parent, mode="create", net=None):
        super().__init__(parent)
        self.mode = mode
        self.net = net or {}
        net = self.net  # rest of this method assumes a dict, even in create mode
        self.setWindowTitle("Create Network" if mode == "create" else f"Edit — {net['name']}")
        self.setMinimumWidth(400)
        self.pool = QThreadPool.globalInstance()

        v = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.name_edit = QLineEdit(net.get("name", "") if net else "")
        self.name_edit.setPlaceholderText("e.g. Home Hotspot")
        form.addRow("Network Name", self.name_edit)

        self.wifi_ifaces = backend.list_wifi_ifaces()
        self.wifi_combo = QComboBox()
        if self.wifi_ifaces:
            for a in self.wifi_ifaces:
                self.wifi_combo.addItem(a, a)
        else:
            self.wifi_combo.addItem("No Wi-Fi adapter found", None)
            self.wifi_combo.setEnabled(False)
        self.wifi_combo.currentIndexChanged.connect(self.on_wifi_changed)
        form.addRow("Wi-Fi Adapter", self.wifi_combo)

        self.inet_combo = QComboBox()
        form.addRow("Internet Adapter", self.inet_combo)

        self.ssid_edit = QLineEdit(net.get("ssid", "") if net else "")
        self.ssid_edit.setPlaceholderText("Network name broadcast over Wi-Fi")
        form.addRow("SSID", self.ssid_edit)

        pw_row = QHBoxLayout()
        self.pw_edit = QLineEdit(net.get("password", "") if net else "")
        self.pw_edit.setPlaceholderText("At least 8 characters")
        self.pw_edit.setEchoMode(QLineEdit.Password)
        pw_row.addWidget(self.pw_edit)
        eye = make_button("👁", "flat")
        eye.setFixedWidth(34)
        eye.clicked.connect(self.toggle_pw)
        pw_row.addWidget(eye)
        form.addRow("Password", pw_row)

        self.band_group = QButtonGroup(self)
        band_row = QHBoxLayout()
        self.band_24 = QRadioButton("2.4 GHz")
        self.band_5 = QRadioButton("5 GHz")
        self.band_group.addButton(self.band_24)
        self.band_group.addButton(self.band_5)
        band_row.addWidget(self.band_24)
        band_row.addWidget(self.band_5)
        form.addRow("Band", band_row)

        self.vis_group = QButtonGroup(self)
        vis_row = QHBoxLayout()
        self.vis_visible = QRadioButton("Visible")
        self.vis_hidden = QRadioButton("Hidden")
        self.vis_group.addButton(self.vis_visible)
        self.vis_group.addButton(self.vis_hidden)
        vis_row.addWidget(self.vis_visible)
        vis_row.addWidget(self.vis_hidden)
        form.addRow("Visibility", vis_row)

        v.addLayout(form)

        self.error_lbl = QLabel("")
        self.error_lbl.setStyleSheet("color: #E4685D; font-weight: 600;")
        self.error_lbl.setWordWrap(True)
        v.addWidget(self.error_lbl)

        btn_row = QHBoxLayout()
        cancel_btn = make_button("Cancel")
        cancel_btn.clicked.connect(self.reject)
        self.save_btn = make_button("Save", "primary")
        self.save_btn.clicked.connect(self.on_save)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(self.save_btn)
        v.addLayout(btn_row)

        # initial state
        if net.get("wifi_iface") and net["wifi_iface"] in self.wifi_ifaces:
            self.wifi_combo.setCurrentIndex(self.wifi_ifaces.index(net["wifi_iface"]))
        self.on_wifi_changed(0)
        if net.get("inet_iface"):
            idx = self.inet_combo.findData(net["inet_iface"])
            if idx >= 0:
                self.inet_combo.setCurrentIndex(idx)

        bands = backend.get_bands_for_iface(net["wifi_iface"]) if net.get("wifi_iface") else ["2.4"]
        self._apply_bands(bands)
        if net.get("band") == "5":
            self.band_5.setChecked(True)
        elif net:
            self.band_24.setChecked(True)
        if net.get("hidden"):
            self.vis_hidden.setChecked(True)
        else:
            self.vis_visible.setChecked(True)

    def _apply_bands(self, bands):
        self.band_24.setEnabled("2.4" in bands)
        self.band_5.setEnabled("5" in bands)
        if "2.4" in bands:
            self.band_24.setChecked(True)
        elif "5" in bands:
            self.band_5.setChecked(True)

    def on_wifi_changed(self, idx):
        iface = self.wifi_combo.currentData()
        self.inet_combo.clear()
        for other in backend.list_other_ifaces(exclude=iface):
            self.inet_combo.addItem(other, other)
        if not backend.list_other_ifaces(exclude=iface):
            self.inet_combo.addItem("No other adapter found", None)
        if iface:
            bands = backend.get_bands_for_iface(iface)
            self._apply_bands(bands)
            if self.mode == "create":
                self.vis_visible.setChecked(True)

    def toggle_pw(self):
        if self.pw_edit.echoMode() == QLineEdit.Password:
            self.pw_edit.setEchoMode(QLineEdit.Normal)
        else:
            self.pw_edit.setEchoMode(QLineEdit.Password)

    def on_save(self):
        data = {
            "name": self.name_edit.text().strip(),
            "ssid": self.ssid_edit.text().strip(),
            "password": self.pw_edit.text(),
            "band": "5" if self.band_5.isChecked() else "2.4",
            "hidden": self.vis_hidden.isChecked(),
            "wifi_iface": self.wifi_combo.currentData(),
            "inet_iface": self.inet_combo.currentData(),
        }
        if self.mode == "create":
            fn, args = backend.create_network, (data,)
        else:
            fn, args = backend.update_network, (self.net["id"], data)

        self.save_btn.setEnabled(False)
        w = Worker(fn, *args)
        w.signals.finished.connect(self._after_save)
        self.pool.start(w)

    def _after_save(self, result):
        self.save_btn.setEnabled(True)
        if result and result.get("error"):
            self.error_lbl.setText(result["error"])
        else:
            self.accept()


class NetworkListRow(Card):
    def __init__(self, net, is_active, on_activate, on_edit, on_delete, parent=None):
        super().__init__(parent)
        row = QHBoxLayout()
        title = QLabel(f"📶  {net['name']}")
        title.setStyleSheet("font-size: 14px; font-weight: 700;")
        row.addWidget(title)
        row.addWidget(Badge(net["wifi_iface"], "info"))
        row.addWidget(Badge(f"{net['band']} GHz", "info"))
        row.addWidget(Badge("Hidden" if net["hidden"] else "Visible",
                             "warn" if net["hidden"] else "off"))
        if is_active:
            row.addWidget(Badge("Active", "ok"))
        row.addStretch()
        if not is_active:
            activate_btn = make_button("Activate", "primary")
            activate_btn.clicked.connect(lambda: on_activate(net["id"]))
            row.addWidget(activate_btn)
        edit_btn = make_button("Edit")
        del_btn = make_button("Delete", "danger")
        edit_btn.clicked.connect(lambda: on_edit(net))
        del_btn.clicked.connect(lambda: on_delete(net))
        row.addWidget(edit_btn)
        row.addWidget(del_btn)
        self.addLayout(row)

        sub = QHBoxLayout()
        sub.addWidget(QLabel(f"SSID: {net['ssid']}"))
        sub.addWidget(QLabel(f"   Internet via: {net['inet_iface']}"))
        sub.addStretch()
        self.addLayout(sub)


class NetworkPage(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.mw = main_window
        self.pool = QThreadPool.globalInstance()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        self.v = QVBoxLayout(content)
        self.v.setContentsMargins(24, 20, 24, 20)
        self.v.setSpacing(16)

        header = QHBoxLayout()
        header.addWidget(SectionTitle("Networks"))
        header.addStretch()
        self.create_btn = make_button("+ Create Network", "primary")
        self.create_btn.clicked.connect(self.on_create)
        header.addWidget(self.create_btn)
        self.v.addLayout(header)

        self.v.addWidget(Hint(
            "You can save multiple networks. Only one is active at a time — "
            "press Activate on a network, then Start it from the Dashboard."))

        self.list_container = QVBoxLayout()
        self.list_container.setSpacing(10)
        self.v.addLayout(self.list_container)

        self.empty_hint = Hint("No networks created yet.")
        self.v.addWidget(self.empty_hint)
        self.v.addStretch()

        self.refresh()

    def refresh(self):
        while self.list_container.count():
            item = self.list_container.takeAt(0)
            wgt = item.widget()
            if wgt:
                wgt.deleteLater()
        nets = backend.get_networks()
        active_id = backend.load_active_id()
        self.empty_hint.setVisible(len(nets) == 0)
        for n in nets:
            self.list_container.addWidget(
                NetworkListRow(n, n["id"] == active_id, self.on_activate,
                               self.on_edit, self.on_delete))

    def on_create(self):
        if not backend.list_wifi_ifaces():
            self.mw.toast.show_message("No Wi-Fi adapter detected on this system", "error")
            return
        dlg = NetworkDialog(self, mode="create")
        if dlg.exec_() == QDialog.Accepted:
            self.mw.toast.show_message("✓ Network created", "success")
            self.refresh()
            self.mw.refresh_current_page_data()

    def on_edit(self, net):
        dlg = NetworkDialog(self, mode="edit", net=net)
        if dlg.exec_() == QDialog.Accepted:
            self.mw.toast.show_message("✓ Network updated", "success")
            self.refresh()
            self.mw.refresh_current_page_data()

    def on_activate(self, nid):
        w = Worker(backend.activate_network, nid)
        w.signals.finished.connect(lambda r: self._after_activate(r))
        self.pool.start(w)

    def _after_activate(self, result):
        if result and result.get("error"):
            self.mw.toast.show_message(result["error"], "error")
        else:
            self.mw.toast.show_message("✓ Network activated", "success")
        self.refresh()
        self.mw.refresh_current_page_data()

    def on_delete(self, net):
        reply = QMessageBox.question(
            self, "Delete Network",
            f"Delete \"{net['name']}\"?",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        w = Worker(backend.delete_network, net["id"])
        w.signals.finished.connect(lambda r: self._after_delete(r))
        self.pool.start(w)

    def _after_delete(self, result):
        if result and result.get("error"):
            self.mw.toast.show_message(result["error"], "error")
        else:
            self.mw.toast.show_message("✓ Network deleted", "success")
        self.refresh()
        self.mw.refresh_current_page_data()
